This folder has 3 files necessary to configure Codeship Pro to execute Cypress end-to-end tests.

- [Dockerfile](Dockerfile)
- [codeship-services.yml](codeship-services.yml)
- [codeship-steps.yml](codeship-steps.yml)
