#!/bin/bash
npm install
npm start &
npm run e2e:chrome